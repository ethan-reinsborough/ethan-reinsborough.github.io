if (FML.isModLoaded("AgriCraft") && AgriCraft_enabled) {
	NEI.override("AgriCraft:waterTank", [0]);
	NEI.override("AgriCraft:waterChannel", [0]);
	NEI.override("AgriCraft:channelValve", [0]);
}